package br.edu.univas;

import java.util.Scanner;

public class teste2 {
	public static void main(String[] args) {
		
	
		Scanner ler = new Scanner(System.in);
		int n = 33;
		int vet[] = new int[n];
		int i,j,aux;
		System.out.println("Valores para o vetor");
			for(i=0; i<n; i++){
				System.out.printf("Informe %2 do.valor :", i+1);
				vet[i]= ler.nextInt();
			}
			for (i = 1; i < n; i++) {
			    for (j = 0; j < i; j++) {
			        if (vet[i] < vet[j]) {
			            aux = vet[i];
			            vet[i] = vet[j];
			            vet[j] = aux;
			        }
			    }
			}
			
			System.out.println("\n Exibindo os valores em ordem crescente: ");
			for (i = 0; i < n; i++) {
		    	System.out.println(vet[i]);
		    }
	}


}
